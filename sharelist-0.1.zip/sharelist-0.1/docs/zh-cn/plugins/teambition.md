# Teambition

由 [drive.teambition.js](https://github.com/reruin/sharelist/tree/master/plugins/drive.teambition.js) 插件实现。 
``` 挂载路径
挂载路径留空
```
将```挂载路径留空```，ShareList将自动开启挂载向导，按指示填写用户名、密码、初始路径。

初始地址可用于选定 初始文件夹 或 初始项目。从官网访问到对应文件夹内，复制浏览器URL 作为初始路径即可。留空时默认为网盘根目录。

绑定网盘时：
```初始地址
https://www.teambition.com/pan/org/xxxxxxxxxx/space/xxxxxxxxxx/folder/xxxxxxxxxx
```
绑定项目时：
```初始地址
https://www.teambition.com/project/xxxxxx/works/xxxxxx
```

?> 未适配国际版。   