# SFTP
SFTP(SSH File Transfer Protocol)，可通过SSH协议建立的安全连接来传输文件，由 [drive.sftp.js](https://github.com/reruin/sharelist/tree/master/plugins/drive.sftp.js) 插件实现。    

```挂载路径
//username:password@server:port/path 
```